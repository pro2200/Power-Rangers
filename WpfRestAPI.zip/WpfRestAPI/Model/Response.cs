﻿using System.Collections.Generic;

namespace WepAPISQLRUD.Model
{
    public class Response
    {
        public int StatusCode { get; set; }
        public string StatusMessage { get; set; }

        public People people { get; set; }
        public List<People> listPeople { get; set; }

    }
}
