﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WepAPISQLRUD.Model;

namespace WpfRestAPI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
   

    public partial class MainWindow : Window
    {

        HttpClient client = new HttpClient();

        public MainWindow()// Constructor
        {

            client.BaseAddress = new Uri("https://localhost:7207/api/Student/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.savePeople();
        }
        private async void savePeople()
        {

            People people = new People();//
            people.Id = int.Parse(IDT.Text);
            people.Name = NameT.Text;
            people.Email = EmailT.Text;
            people.Age = float.Parse(AgeT.Text);

                HttpResponseMessage response = await client.PostAsJsonAsync<People>("AddPeople", people);
            
            //Here we are trying to get/catch teh response from teh RestAPI server .. the response
            //will always follow the structure of the Response class we have made before
            //it will have the status code, 
            
            
            
            Response res = JsonConvert.DeserializeObject<Response>(response.ToString());
            serverstatus.Content = response.StatusCode.ToString();
        }
    }
}
