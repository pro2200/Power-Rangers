﻿using System;
using System.Data.SqlClient;

namespace Project
{
    internal class sqlCommand
    {
        public object Paremeters { get; internal set; }

        public static implicit operator sqlCommand(SqlCommand v)
        {
            throw new NotImplementedException();
        }
    }
}