﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection con;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=master;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            con = new SqlConnection(connectionString);
            con.Open();
            MessageBox.Show("Connection Established Properly");
            con.Close();
        
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

            // Open the Database Connection
            con.Open();
            String query = "Insert into projectTable values(@Id, @FirstName, @lastName, @Email, @PhoneNumber, @Address, @PostalCode, @City, @Province, @DriversLicence, @BedSize3, @CreditCardNumber, @CreditCardOptions, @ExpireDate, @CVV, @TypesOfServices, @TimeOfStay, @DateofBirth)";
            SqlCommand cmd = new SqlCommand(query, con);
            
            cmd.Parameters.AddWithValue("@Id", int.Parse(Id.Text)); // we need call the textbox name and then grab the text 
            cmd.Parameters.AddWithValue("@FirstName", FirstName.Text);
            cmd.Parameters.AddWithValue("@LastName", LastName.Text);
            cmd.Parameters.AddWithValue("@Email", Email.Text);
            cmd.Parameters.AddWithValue("@PhoneNumber", float.Parse(PhoneNumber.Text));
            cmd.Parameters.AddWithValue("@Address", Address.Text);
            cmd.Parameters.AddWithValue("@PostalCode", PostalCode.Text);
            cmd.Parameters.AddWithValue("@City", City.Text);
            cmd.Parameters.AddWithValue("@Province", Province.Text);
            cmd.Parameters.AddWithValue("@DriversLicence", DriversLicence.Text);
            cmd.Parameters.AddWithValue("@BedSize3", BedSize3.Text);
            cmd.Parameters.AddWithValue("@CreditCardNumber", CreditCardNumber.Text);
            cmd.Parameters.AddWithValue("@CreditCardOptions", CreditCardOptions.Text);
            cmd.Parameters.AddWithValue("@ExpireDate", ExpireDate.Text);
            cmd.Parameters.AddWithValue("@CVV", CVV.Text);
            cmd.Parameters.AddWithValue("@TypesOfServices", TypesOfServices.Text);
            cmd.Parameters.AddWithValue("@TimeOfStay", TimeOfStay.Text);
            cmd.Parameters.AddWithValue("@DateofBirth", DateofBirth.Text);

            //we need to execute query

            cmd.ExecuteNonQuery();
            MessageBox.Show("inserted perfeclty to the database");
            con.Close();


        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            // Open the Database Connection
            con.Open();
            String query = "Updated into projectTable values(@Id, @FirstName, @lastName, @Email, @PhoneNumber, @Address, @PostalCode, @City, @Province, @DriversLicence, @BedSize3, @CreditCardNumber, @CreditCardOptions, @ExpireDate, @CVV, @TypesOfServices, @TimeOfStay, @DateofBirth)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@Id", int.Parse(Id.Text)); // we need call the textbox name and then grab the text 
            cmd.Parameters.AddWithValue("@FirstName", FirstName.Text);
            cmd.Parameters.AddWithValue("@LastName", LastName.Text);
            cmd.Parameters.AddWithValue("@Email", Email.Text);
            cmd.Parameters.AddWithValue("@PhoneNumber", float.Parse(PhoneNumber.Text));
            cmd.Parameters.AddWithValue("@Address", Address.Text);
            cmd.Parameters.AddWithValue("@PostalCode", PostalCode.Text);
            cmd.Parameters.AddWithValue("@City", City.Text);
            cmd.Parameters.AddWithValue("@Province", Province.Text);
            cmd.Parameters.AddWithValue("@DriversLicence", DriversLicence.Text);
            cmd.Parameters.AddWithValue("@BedSize3", BedSize3.Text);
            cmd.Parameters.AddWithValue("@CreditCardNumber", CreditCardNumber.Text);
            cmd.Parameters.AddWithValue("@CreditCardOptions", CreditCardOptions.Text);
            cmd.Parameters.AddWithValue("@ExpireDate", ExpireDate.Text);
            cmd.Parameters.AddWithValue("@CVV", CVV.Text);
            cmd.Parameters.AddWithValue("@TypesOfServices", TypesOfServices.Text);
            cmd.Parameters.AddWithValue("@TimeOfStay", TimeOfStay.Text);
            cmd.Parameters.AddWithValue("@DateofBirth", DateofBirth.Text);

            //we need to execute query

            cmd.ExecuteNonQuery();
            MessageBox.Show("Updated perfeclty to the database");
            con.Close();


        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            // Open the Database Connection
            con.Open();
            String query = "Delete into projectTable values(@Id, @FirstName, @lastName, @Email, @PhoneNumber, @Address, @PostalCode, @City, @Province, @DriversLicence, @BedSize3, @CreditCardNumber, @CreditCardOptions, @ExpireDate, @CVV, @TypesOfServices, @TimeOfStay, @DateofBirth)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@Id", int.Parse(Id.Text)); // we need call the textbox name and then grab the text 
            cmd.Parameters.AddWithValue("@FirstName", FirstName.Text);
            cmd.Parameters.AddWithValue("@LastName", LastName.Text);
            cmd.Parameters.AddWithValue("@Email", Email.Text);
            cmd.Parameters.AddWithValue("@PhoneNumber", float.Parse(PhoneNumber.Text));
            cmd.Parameters.AddWithValue("@Address", Address.Text);
            cmd.Parameters.AddWithValue("@PostalCode", PostalCode.Text);
            cmd.Parameters.AddWithValue("@City", City.Text);
            cmd.Parameters.AddWithValue("@Province", Province.Text);
            cmd.Parameters.AddWithValue("@DriversLicence", DriversLicence.Text);
            cmd.Parameters.AddWithValue("@BedSize3", BedSize3.Text);
            cmd.Parameters.AddWithValue("@CreditCardNumber", CreditCardNumber.Text);
            cmd.Parameters.AddWithValue("@CreditCardOptions", CreditCardOptions.Text);
            cmd.Parameters.AddWithValue("@ExpireDate", ExpireDate.Text);
            cmd.Parameters.AddWithValue("@CVV", CVV.Text);
            cmd.Parameters.AddWithValue("@TypesOfServices", TypesOfServices.Text);
            cmd.Parameters.AddWithValue("@TimeOfStay", TimeOfStay.Text);
            cmd.Parameters.AddWithValue("@DateofBirth", DateofBirth.Text);
            //we need to execute query

            cmd.ExecuteNonQuery();
            MessageBox.Show("Deleted in the database");
            con.Close();


        }

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            // Open the Database Connection
            con.Open();
            String query = "Search into projectTable values(@Id, @FirstName, @lastName, @Email, @PhoneNumber, @Address, @PostalCode, @City, @Province, @DriversLicence, @BedSize3, @CreditCardNumber, @CreditCardOptions, @ExpireDate, @CVV, @TypesOfServices, @TimeOfStay, @DateofBirth)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@Id", int.Parse(Id.Text)); // we need call the textbox name and then grab the text 
            cmd.Parameters.AddWithValue("@FirstName", FirstName.Text);
            cmd.Parameters.AddWithValue("@LastName", LastName.Text);
            cmd.Parameters.AddWithValue("@Email", Email.Text);
            cmd.Parameters.AddWithValue("@PhoneNumber", float.Parse(PhoneNumber.Text));
            cmd.Parameters.AddWithValue("@Address", Address.Text);
            cmd.Parameters.AddWithValue("@PostalCode", PostalCode.Text);
            cmd.Parameters.AddWithValue("@City", City.Text);
            cmd.Parameters.AddWithValue("@Province", Province.Text);
            cmd.Parameters.AddWithValue("@DriversLicence", DriversLicence.Text);
            cmd.Parameters.AddWithValue("@BedSize3", BedSize3.Text);
            cmd.Parameters.AddWithValue("@CreditCardNumber", CreditCardNumber.Text);
            cmd.Parameters.AddWithValue("@CreditCardOptions", CreditCardOptions.Text);
            cmd.Parameters.AddWithValue("@ExpireDate", ExpireDate.Text);
            cmd.Parameters.AddWithValue("@CVV", CVV.Text);
            cmd.Parameters.AddWithValue("@TypesOfServices", TypesOfServices.Text);
            cmd.Parameters.AddWithValue("@TimeOfStay", TimeOfStay.Text);
            cmd.Parameters.AddWithValue("@DateofBirth", DateofBirth.Text);

            //we need to execute query

            cmd.ExecuteNonQuery();
            MessageBox.Show("Search in the database");
            con.Close();


        }
    }
}
