﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using WepAPISQLRUD.Controllers;
using WepAPISQLRUD.Model;

namespace WepAPISQLRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly IConfiguration _configuration; //receive and request the connection

        public StudentController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        // to read the data from teh server student table 
        [HttpGet]
        [Route("GetAllStudent")]

        public Response GetAllStudent()
        {
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("StudentCon").ToString());
            Response response = new Response();
            Application apl = new Application();
            response = apl.GetAllStudents(con);
            return response;
        }
        // to insert data in my student table 
        [HttpPost]
        [Route("AddStudent")]

        public Response AddStudent(Student student)
        {
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("StudentCon").ToString());
            Response response = new Response();
            Application apl = new Application();
            response = apl.AddStudent(con, student);
            return response;

        }

    }
}
