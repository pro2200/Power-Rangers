﻿namespace WepAPISQLRUD.Model
{
    public class Response
    {
        public int StatusCode { get; set; }
        public string StatusMessage { get; set; }

        public Student student { get; set; }
        public List<Student> listStudent { get; set; }

    }
}
